import React from 'react'



const Grocery = () => {
    return (
        <div>
            grocery
        </div>
    )
}

export default Grocery;